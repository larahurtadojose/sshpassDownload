#!/bin/bash
set +x 
##############################################################################################
##############################################################################################
##                                                                                          ##
## Script De Historificacion De Journal                                                     ## 
## ------ -- --------------- -- -------                                                     ##
## PASO 1: Se conecta a la base datos de ADH                y halla la fecha                ##
##         Juliana, a continuaci�n el "case" calcula la paridad del �ltimo                  ##
##         digito que devolvio la fecha Juliana:                                            ##
##              0,2,4,6,8= Se Descargaran Tablas Pares (_1)                                 ##
##              1,3,5,7,9= Se Descargaran Tablas Impares (_2)                               ##
##                                                                                          ##
## PASO 2: Genera Scripts Load Ejecutando Pgm Gestion Tablas Ciclicas (Insert/Replace)      ##
##                                                                                          ##
## PASO 3: Descarga de la tabla journal                                                     ##
##                                                                                          ##
##         * El formato de los ficheros es el siguiente:                                    ##
##           . journal_basedatos_fecha_a (Current Day)                                      ##
##           . journal_basedatos_fecha_b (Current Date -1 day)                              ##
##                                                                                          ##
## PASO 4: Pgm gestion tablas ciclicas con fecha de hoy                                     ##
##         genera script de load con replace e inicializa particion nueva                   ##                                   
##         Pgm gestion tablas ciclicas con fecha de ayer                                    ##
##         genera script de load con insert carga sobre particion existente                 ##
##                                                                                          ##
## Variables:                                                                               ##
##     INSTANCIA: Nombre Instancia Local (Historico M�icas)                               ##
##     LOCALDB..: Nombre Base Datos Local (Historico M�icas)                              ##
##     REMOTEDB.: Nombres Bases Datos Remotas (Tablas Diarias Online)                       ##
##     FICH.....: Path Ficheros Descargas Tablas Online                                     ##
##     FICH2....: Path Scripts M�icas                                                     ##
##     FECHA....: Current Date                                                              ##
##     FECHAAYER:  Current Date -1 Dia                                                      ##
##     DIAJULIANO: Fecha Juliana                                                            ##
##     PARIDAD....: Paridad De La Fecha Juliana                                             ##
##############################################################################################

#---------------
# MODIFICATION 04/11/2015
# DELETE RECORDS FROM JOURNAL1 AND JOURNAL2 BY COMMIT
# - New FUNCTIONS section added. Include new function func_delete_bycommit
# - Included new parameter COMMIT_EVERY , related to function func_delete_bycommit
# - In the Step 5, replace the db2 deletion commands by the new function call.
# STATUS VARIABLE IN STEP 4
# - Change the "if [ $STATUS = 0 ]" for this other "if [ $STATUS -eq 0 ]"
#---------------

#---------------
# MODIFICATION 06/11/2015
# DELETE FILES PROCESS
# - New control over days_to_delete_export_dir , days_to_delete_returnCodes_dir and 
#   days_to_delete_log_dir parameters. if set to 0, there is no Delete for those files.
#
# LOG STATUS FILE FOR CONTROL-M
# - new func_write_status_log function created
# - new func_delete_log_file function created
# - new func_create_log_status_file fucntion created
# - new func_check_status_destination_table function created
# - new func_check_access_view function created
# - new new parameters included STATUS_LOG_DIR 
# - new parameter included JOURNAL_VIEW_SCHEMA.
# - new func_evaluate_connectorProperties (NEED UNZIP)
# - improved func_delete_bycommit function. (got out of the loop if something wrong)
# - Many lines on the script has been changed, added, deleted or adjusted, to satisfy the error
#   control flow.
# - java database connection controled.
# - The File TABLAS_DESCARGADAS.TXT , has changed. Now contains a date execution.
#   . Now you would find the file like this: TABLAS_DESCARGADAS_20151119.13.12.44.txt
#   . Also, has better looking dividev by sections.
# - included .txt extention on the delele export directory.
#---------------   
#
#---------------
# MODIFICATION 19/01/2016
# - Change on the Alert message for control-m team
# - Added exit status at the end of the script
# - exit 0 - OK
# - exit 1 - KO
#---------------
#

######################################################################################
##  VARIABLES                                                                       ##
######################################################################################

#INSTANCIA=`whoami`
#. /bbdd_$INSTANCIA/.profile
STATUS=0
PARIDAD=' '
USUARIO='####'
LOCALDB='####'
REMOTEDB='####'
PASSREMOTEDB='####'
FICH='/####/####/historificacion/export'
FICH2='/####/####/historificacion'
FECHAAYER=' '
DIA=' ' 
days_to_delete_export_dir=30
days_to_delete_returnCodes_dir=30
days_to_delete_log_dir=30
#This two values should be opposite to ADH.
ADH_EVEN_TABLE="journal2"
ADH_ODD_TABLE="journal1"
COMMIT_EVERY="1000" #1000 would be a good start
STATUS_LOG_DIR="/####/historificacion/log"
JOURNAL_VIEW_SCHEMA="ATMHIST" #tipically ATMHIST

######################################################################################
##  FUNCTIONS                                                                       ##
######################################################################################

func_delete_bycommit(){
echo "- Delete on $TABLE_TO_EXPORT from $YESTERDAY starts..."
total_resultado=1
error_during_delete_online=0
while [ $total_resultado -gt 0 ] && [ $STATUS_OPERATION -eq 0 ]
do
  str="total:" ; resultado=`db2 -x "SELECT '$str' ||count(*) FROM atminf.$TABLE_TO_EXPORT where RECORDTIME >= TIMESTAMP ('$YESTERDAY-00.00.00.000000') AND RECORDTIME < TIMESTAMP ('$YESTERDAY-23.59.59.999999')"`
  total_resultado=`echo $resultado | grep "$str" | cut -d ":" -f2`
  
 if [ "$total_resultado" -eq "$total_resultado" ] 2>/dev/null; then
        #its a number
      if [ $total_resultado -eq 0 ]; then
         echo 
         echo "Records: $total_resultado"
      else
         echo "| $total_resultado | records left"
         resultado_delete=`db2 "delete from (SELECT * FROM atminf.$TABLE_TO_EXPORT where RECORDTIME >= TIMESTAMP ('$YESTERDAY-00.00.00.000000') AND RECORDTIME < TIMESTAMP ('$YESTERDAY-23.59.59.999999') FETCH FIRST $COMMIT_EVERY ROWS ONLY)"`
         
         if [[ $resultado_delete == *The*SQL*command*completed*successfully* ]]; then
            echo "Deleting $COMMIT_EVERY .. OK"
         else
            STATUS_OPERATION=2
            echo "------------------------------------"
            echo "ERROR: The Delete command has failed"
            echo "------------------------------------"
         fi
         result_commit=`db2 commit`
         if [[ $resultado_delete == *The*SQL*command*completed*successfully* ]]; then
            echo "commit..OK"
         else
            STATUS_OPERATION=2
            echo "------------------------------------"
            echo "ERROR: The commit command has failed"
            echo "------------------------------------"
         fi
      fi
  else 
     #something else
     STATUS_OPERATION=2
     echo "------------------------------------------"
     echo "ERROR: The count result is not a number"
     echo "------------------------------------------"
     echo "total_resultado: $total_resultado"
  fi
done
result_reset=`db2 connect reset`
if [[ $result_reset == *The*SQL*command*completed*successfully* ]]; then
   echo "connect reset..OK"
else
   STATUS_OPERATION=2
   echo "----------------------------------------------"
   echo "ERROR: The connet reset command has failed"
   echo "----------------------------------------------"
fi
echo "- Delete on $TABLE_TO_EXPORT from $YESTERDAY ENDS."
}

func_write_status_log(){
text=$1
echo $text
echo $text >> $STATUS_LOG_FILE
}

func_create_log_status_file(){
echo "---------------------------------------------------------------------------------------------------------------"
echo "CREATING NEW LOG FILE $STATUS_LOG_FILE"
echo "---------------------------------------------------------------------------------------------------------------"
NOW_FILE=$(date +"%Y%m%d.%H.%M.%S")
echo ";Execution time: "$NOW_FILE > $STATUS_LOG_FILE
echo "; 0=OK                                                                   " >> $STATUS_LOG_FILE
echo "; 1=OK                                                                   " >> $STATUS_LOG_FILE
echo ";    - No records found to export.....................................KO " >> $STATUS_LOG_FILE
echo "; 2=OK                                                                   " >> $STATUS_LOG_FILE
echo ";     - Records exported/loaded.......................................OK " >> $STATUS_LOG_FILE
echo ";     - Issues under this code:                                          " >> $STATUS_LOG_FILE
echo ";        . Delete records from online fails in some point.............KO " >> $STATUS_LOG_FILE
echo ";        . partition table error-count or JOURNAL view inaccessible...KO " >> $STATUS_LOG_FILE
echo "; 3=OK                                                                   " >> $STATUS_LOG_FILE
echo ";     - Reserved for future problems.                                    " >> $STATUS_LOG_FILE
echo "; 4=KO                                                                   " >> $STATUS_LOG_FILE
echo ";     - major problem. See the execution output.                         " >> $STATUS_LOG_FILE
echo ";                                                                        " >> $STATUS_LOG_FILE
if [ -f "$STATUS_LOG_FILE" ]; then
   echo
   echo "OK. Log created."
   echo
   #STATUS_OPERATION=0
else
   echo
   echo "Error: Log could not be created."
   echo
   STATUS_OPERATION=4
fi
}
func_delete_log_file(){
if [ -f "$STATUS_LOG_FILE" ]; then
   echo "---------------------------------------------------------------------------------------------------------------"
   echo "DELETING LOG FILE $STATUS_LOG_FILE"
   echo "---------------------------------------------------------------------------------------------------------------"
   ok_rm=$?
   rm -f $STATUS_LOG_FILE
   ok_rm=$?
   if [ $ok_rm -eq 0 ]; then
       echo
       echo "OK. Log deleted."
       echo
       #STATUS_OPERATION=0
       func_create_log_status_file
   else
       echo
       echo "Error: Log could not be deleted."
       echo
       STATUS_OPERATION=4
   fi
else
   echo "---------------------------------------------------------------------------------------------------------------"
   echo "LOG FILE $STATUS_LOG_FILE NOT FOUND, maybe first time execution"
   echo "---------------------------------------------------------------------------------------------------------------"
   func_create_log_status_file
fi
}

func_check_access_view(){
echo "---------------------------------------------------------------------------------------------------------------"
echo "Evaluating access to partitions counting view $JOURNAL_VIEW_SCHEMA.JOURNAL       "
echo "---------------------------------------------------------------------------------------------------------------"
str="total_view_count:" ; resultado=`db2 -x "SELECT '$str' ||count(*) FROM $JOURNAL_VIEW_SCHEMA.JOURNAL"`
if [[ $resultado == *SQLSTATE* ]]; then
   STATUS_OPERATION=2
   echo
   echo "Error check1: querying $JOURNAL_VIEW_SCHEMA.JOURNAL view on $LOCALDB DB "
   echo "       some of the partition must have an issue."
   echo $resultado
   echo
else
   #just making double check here
   #resutado must be a number
   total_result_view_count=`echo $resultado | grep "$str" | cut -d ":" -f2`
   if [ "$total_result_view_count" -eq "$total_result_view_count" ] 2>/dev/null; then
      #its a number
      #STATUS_OPERATION=0
      echo
      echo "OK. We have access to the view. Count: $total_result_view_count"
      echo
   else
      #its not a number
      STATUS_OPERATION=2
      echo
      echo "Error check2: querying $JOURNAL_VIEW_SCHEMA.JOURNAL view on $LOCALDB DB "
      echo "       some of the partition must have an issue."
      echo $resultado
      echo
   fi
fi
}

func_check_status_destination_table(){
total_result_count=0
dest_table=$1
regs_loaded=$2
echo "---------------------------------------------------------------------------------------------------------------"
echo "Evaluating $dest_table table count"
echo "---------------------------------------------------------------------------------------------------------------"
resultado=`db2 connect to $LOCALDB`
status_con=$?
if [ $status_con -gt 0 ]; then 
   STATUS_OPERATION=2
   echo
   echo "Error: connecting to $LOCALDB "
   echo
   echo $resultado
   echo
else
	str="total_count:" ; resultado=`db2 -x "SELECT '$str' ||count(*) FROM $dest_table"`
    if [[ $resultado == *SQLSTATE* ]]; then
       STATUS_OPERATION=2
       echo
       echo "Error: querying $dest_table table on $LOCALDB DB "
       echo
       echo $resultado
       echo
    else
	   total_result_count=`echo $resultado | grep "$str" | cut -d ":" -f2`
	   if [ $total_result_count -eq $regs_loaded ]; then
	      #STATUS_OPERATION=0
          echo 
          echo "OK. Match.    Loaded : $regs_loaded    Counted: $total_result_count"
          echo
          func_check_access_view
	   else
	      STATUS_OPERATION=2
          echo 
          echo "Warning: The Records loaded on $dest_table does not match"
          echo "         with the recent count."
          echo "Loaded : $regs_loaded"
          echo "Counted: $total_result_count"
          echo 
	   fi
       result_reset=`db2 connect reset`
       if [[ $result_reset == *The*SQL*command*completed*successfully* ]]; then
          echo "connect reset..OK"
       else
          STATUS_OPERATION=2
          echo "----------------------------------------------"
          echo "ERROR: The connet reset command has failed"
          echo "----------------------------------------------"
       fi
    fi
fi
} 
 
func_evaluate_connectorProperties(){
jar_file="Tablasciclicas.jar"
jar_file_dir="$FICH2""/ciclicas/"
complete_jar_file="$jar_file_dir""$jar_file"
properties_file_on_jar="conector.properties"
echo "---------------------------------------------------------------------------------------------------------------"
echo "Evaluating $properties_file_on_jar from the $jar_file"
echo "---------------------------------------------------------------------------------------------------------------"
if [ -f "$complete_jar_file" ]; then
   echo "$jar_file found. "
   conProp_user=`unzip -c "$complete_jar_file" "GTC/""$properties_file_on_jar" | grep "user=" | sed s/'='/' '/g | awk '{ print $2 }'`
   conProp_passwd=`unzip -c "$complete_jar_file" "GTC/""$properties_file_on_jar" | grep "password=" | sed s/'='/' '/g | awk '{ print $2 }'`
   conProp_DB_cadena=`unzip -c "$complete_jar_file" "GTC/""$properties_file_on_jar" | grep "cadenadeconexion=" | sed s/'='/' '/g | awk '{ print $2 }'`
   conProp_DB=`echo $conProp_DB_cadena | sed s/':'/' '/g | awk '{ print $3 }'`
   if [ ${#conProp_user} -le 1 ] || 
      [ ${#conProp_passwd} -le 1 ] ||
      [ ${#conProp_DB} -le 1 ]
   then
     STATUS_OPERATION=4
     echo 
     echo "Error: Some parameter connection are missing in $properties_file_on_jar"
     echo
   else
         #todo minuscula
		 conProp_DB_lowercase=`echo $conProp_DB | tr '[:upper:]' '[:lower:]' | tr -d '\n'`
		 LOCALDB_lowercase=`echo $LOCALDB | tr '[:upper:]' '[:lower:]'| tr -d '\n'`
         # quitamos \r
         conProp_DB_lowercase=$(echo $conProp_DB_lowercase | tr -d '\r') 
         LOCALDB_lowercase=$(echo $LOCALDB_lowercase | tr -d '\r') 
         
		 if [ "$conProp_DB_lowercase" == "$LOCALDB_lowercase" ]; then
			 echo "OK. Localdb definition match with $properties_file_on_jar definition."
             echo
             #STATUS_OPERATION=0
		 else
           STATUS_OPERATION=4
		   echo
           echo "Error: Localdb definition does NOT match with $properties_file_on_jar definition. "
           echo
		   echo "user conector.properties   : $conProp_user"
		   echo "passwd conector.properties : $conProp_passwd"
		   echo "DB conector.properties     : $conProp_DB_lowercase"
		   echo "DB script                  : $LOCALDB_lowercase"
		   echo
		 fi
   fi
else
   echo 
   echo "Error: $jar_file NOT found in $jar_file_dir "
   echo
   STATUS_OPERATION=4
fi 


}


######################################################################################
##  PASO 1: FECHA JULIANA Y PARIDAD                                                 ##
######################################################################################
     echo
     echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
     echo "ENVIROMENT SETUP"
     echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
     echo
    STATUS_OPERATION=0
    FECHA=`date +"%Y%m%d"`
    NOW_DATE_FILE=$(date +"%Y%m%d.%H.%M.%S")
    STATUS_LOG_FILE="$STATUS_LOG_DIR""/""histo_status_log.log"
    exported_tables="$FICH""/""TABLAS_DESCARGADAS_""$NOW_DATE_FILE"".txt"

    func_delete_log_file
        
  if [ $STATUS_OPERATION -lt 4 ]; then
     func_evaluate_connectorProperties
     echo
     echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
     echo "SETTING DATES"
     echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
     echo
    db2 connect to $LOCALDB; 
    status_con=$?
    if [ $status_con -gt 0 ]; then 
       STATUS_OPERATION=4
       echo
       echo "Error: connecting to $LOCALDB "
       echo
    else
      db2 "select 'paridad '||substr(char(julian_day(fecha)), 7, 1) from (select current_date as fecha from sysibm.sysdummy1) as x"|grep paridad|awk '{print $2}' > $FICH/juliana.tmp
      DIAJULIANO=`cat "$FICH/juliana.tmp"`
      #db2 "select 'fecha '||substr(char(fecha), 7, 4)||substr(char(fecha), 1, 2)||substr(char(fecha), 4, 2) from (select current_date - 1 day as fecha from sysibm.sysdummy1)" > $FICH/ayer.tmp
      db2 "SELECT 'fecha ' ||VARCHAR_FORMAT(CURRENT TIMESTAMP - 1 day, 'YYYYMMDD')  AS fecha FROM SYSIBM.SYSDUMMY1" > $FICH/ayer.tmp
	  db2 connect reset;
      FECHAAYER=`cat $FICH/ayer.tmp|grep fecha|awk '{print $2}'`
      echo
	  echo "Today: $FECHA - Julian date reference: $DIAJULIANO"
	  echo "Yesterday: $FECHAAYER"
      echo
	  
      case $DIAJULIANO in
        0|2|4|6|8) PARIDAD='PAR';;
        1|3|5|7|9) PARIDAD='IMPAR';;
      esac
    fi
  fi
######################################################################################
## PASO 2: GENERACION SCRIPTS LOAD CON EJECUCION PGM TABLAC CICLICAS                ##
######################################################################################
 if [ $STATUS_OPERATION -lt 4 ]; then
    echo
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo "Generating loads scripts and setting up histo database"
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo
    cd $FICH2/ciclicas
    
    ## FECHA AYER (CREATING LOAD INSERT)                                                         
    yesterday_load_script_gen=`./make.ssh $FECHAAYER JOURNAL $FICH2/skel/load_journal_insert.txt`
    status_make1=$?
    
    ## FECHA HOY (CREATING LOAD REPLACE)                                                         
    today_load_script_gen=`./make.ssh $FECHA JOURNAL $FICH2/skel/load_journal_replace.txt`
    status_make2=$?
    if [ $status_make1 -gt 0 ] || [ $status_make2 -gt 0 ]; then
       echo
       echo "Error: Make execution Fails."
       echo "status_make1: $status_make1"
       echo "status_make2: $status_make2"
       echo
       STATUS_OPERATION=4
    else

       if [[ $yesterday_load_script_gen == *abrirConexion:*conexion*establecida*con*exito* ]]; then
          echo
          echo "Yesterday java connection $conProp_DB_lowercase .. OK"
       else
          STATUS_OPERATION=4
          echo
          echo "Error: Yesterday java connection."
          echo "$yesterday_load_script_gen"
          echo
		  echo "user conector.properties   : $conProp_user"
		  echo "passwd conector.properties : $conProp_passwd"
		  echo "DB conector.properties     : $conProp_DB_lowercase"

       fi
    
       if [[ $today_load_script_gen == *abrirConexion:*conexion*establecida*con*exito* ]]; then
          echo "Today java connection $conProp_DB_lowercase     .. OK"
       else
          STATUS_OPERATION=4
          echo
          echo
          echo "Error: Today java connection."
          echo "$yesterday_load_script_gen"
          echo
		  echo "user conector.properties   : $conProp_user"
		  echo "passwd conector.properties : $conProp_passwd"
		  echo "DB conector.properties     : $conProp_DB_lowercase"

       fi
 
    fi
  fi
#######################################################################################
###  PASO 3: Realiza Conexi� Todas Las Bases Datos Online Catalogadas y Realiza   ##
##          Export De Los Datos Actuales y Dia -1                                   ##
###################################################################################### 
if [ $STATUS_OPERATION -lt 4 ]; then
   echo
   echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
   echo "Exportation process "
   echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
   echo
   echo "-----------------------------------" >> $exported_tables
   echo `date` >> $exported_tables
   echo "-----------------------------------" >> $exported_tables
   db2 connect to $REMOTEDB user $USUARIO using $PASSREMOTEDB >> $exported_tables
   status_con=$?
   if [ $status_con -gt 0 ]; then 
       STATUS_OPERATION=4
       echo
       echo "Error: connecting to $REMOTEDB "
       echo " see $exported_tables for details."
       echo
   else
     	  DIAA=`echo $REMOTEDB'_'$FECHA'_a'`
		  DIAB=`echo $REMOTEDB'_'$FECHA'_b'`
		  
		  if [ $PARIDAD = 'PAR' ]; then
			TABLE_TO_EXPORT=$ADH_EVEN_TABLE
			echo "TODAY:$FECHA - YESTERDAY:$FECHAAYER - PARITY:$PARIDAD - EXPORTED $FECHAAYER FROM $TABLE_TO_EXPORT - BBDD $REMOTEDB" >> $exported_tables
            echo
            echo "Parity: $PARIDAD"
            echo "Export from table: $TABLE_TO_EXPORT"
            echo
            db2 "export to $FICH/journal_$DIAA.ixf of ixf select * from atminf.$TABLE_TO_EXPORT where date(RECORDTIME)=current date" > $FICH/result_export_today.txt
            status_export1=$?
			db2 "export to $FICH/journal_$DIAB.ixf of ixf select * from atminf.$TABLE_TO_EXPORT where date(RECORDTIME)=current date - 1 day"  > $FICH/result_export_yesterday.txt
             status_export2=$?
				if [ $status_export1 -gt 0 ] || [ $status_export2 -gt 0 ]; then
					   echo
					   echo "Error: Export Fail."
					   echo "status_export1: $status_export1"
					   echo "status_export2: $status_export2"
					   echo
					   STATUS_OPERATION=4
				fi
		  else
		   if [ $PARIDAD = 'IMPAR' ];  then
			  TABLE_TO_EXPORT=$ADH_ODD_TABLE
			  echo "TODAY:$FECHA - YESTERDAY:$FECHAAYER - PARITY:$PARIDAD - EXPORTED $FECHAAYER FROM $TABLE_TO_EXPORT - BBDD $REMOTEDB" >> $exported_tables
              echo
              echo "Parity: $PARIDAD"
              echo "Export from table: $TABLE_TO_EXPORT"
              echo
			  db2 "export to $FICH/journal_$DIAA.ixf of ixf select * from atminf.$TABLE_TO_EXPORT where date(RECORDTIME)=current date" > $FICH/result_export_today.txt
              status_export1=$?
			  db2 "export to $FICH/journal_$DIAB.ixf of ixf select * from atminf.$TABLE_TO_EXPORT where date(RECORDTIME)=current date - 1 day" > $FICH/result_export_yesterday.txt
              status_export2=$?
				if [ $status_export1 -gt 0 ] || [ $status_export2 -gt 0 ]; then
					   echo
					   echo "Error: Export Fails."
					   echo "status_export1: $status_export1"
					   echo "status_export2: $status_export2"
					   echo
					   STATUS_OPERATION=4
				fi
		   fi
		  fi
          echo                                  >> $exported_tables
          echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
          echo "EXPORT RESULT TODAY"            >> $exported_tables
          echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
		  cat $FICH/result_export_today.txt     >> $exported_tables
          echo                                  >> $exported_tables
          echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
          echo "EXPORT RESULT YESTERDAY"        >> $exported_tables
          echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
		  cat $FICH/result_export_yesterday.txt >> $exported_tables
		
    fi
fi
######################################################################################
## PASO 4: EJECUCION SCRIPTS LOAD EN TABLAS HISTORICAS                              ##
######################################################################################
if [ $STATUS_OPERATION -lt 4 ]; then
     echo
     echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
     echo "LOAD process "
     echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
     echo
     cd $FICH2
     chmod 700 load_*.txt
	 
	 # Nuevo parametro $REMOTEDB agregado como $3.
	 # Ademas es necesario modificar los 2 fichero skels
	 # para que usen este nuevo parametro.
	 #
	 # El problema es que los fichero .ixf se crean con la variable $REMOTEDB
	 # en las lineas 96 y 97. Pero en la carga los archivos se buscaban con la 
	 # variable $LOCALDB por lo que nunca los encontraba.
	 
     ./load_journal_insert.txt $LOCALDB $FECHA $REMOTEDB > $FICH2/return_codes/RETURN_CODES_YESTERDAY_$FECHA.txt
     status_load1=$?
     ./load_journal_replace.txt $LOCALDB $FECHA $REMOTEDB > $FICH2/return_codes/RETURN_CODES_TODAY_$FECHA.txt
     status_load2=$?
     if [ $status_load1 -gt 0 ] || [ $status_load2 -gt 0 ]; then
		echo
		echo "Error: Load Fails."
		echo "status_load1: $status_load1"
		echo "status_load2: $status_load2"
		echo
		STATUS_OPERATION=4
	fi
    echo                                                      >> $exported_tables
    echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
    echo "LOAD RESULT TODAY"                                  >> $exported_tables
    echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
    cat $FICH2/return_codes/RETURN_CODES_TODAY_$FECHA.txt     >> $exported_tables
    echo                                                      >> $exported_tables
    echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
    echo "LOAD RESULT YESTERDAY"                              >> $exported_tables
    echo "-----------------------------------------------------------------------------------"                        >> $exported_tables
    cat $FICH2/return_codes/RETURN_CODES_YESTERDAY_$FECHA.txt >> $exported_tables
fi
#
# INTERMEDIATE STEP TO SEE THE EXPORT AND LOAD REPORT
#
if [ $STATUS_OPERATION -lt 4 ]; then
    tot_regs_exported=0
	# REFORMATEAMOS LAS FECHAS
	YESTERDAY=`date -d $FECHAAYER +"%Y-%m-%d"`
	TODAY=`date -d $FECHA +"%Y-%m-%d"`
	
      #just for simulation cases
      #Con esto, el proceso de exportacion y carga se hace de forma natural,
      #pero el borrado se hace con lo que ponga aqui.
      #YESTERDAY="2015-03-30"
      #      

	#DATOS DE HISTORIFICACION
	table_histo_TODAY=`cat $FICH2/return_codes/RETURN_CODES_TODAY_$FECHA.txt | grep "DROP CONSTRAINT JOURNAL" | awk '{print $3}'`
	#table_histo_YESTERDAY=`cat $FICH2/return_codes/RETURN_CODES_YESTERDAY_$FECHA.txt | grep "IMMEDIATE CHECKED" | awk '{print $4}'`
	table_histo_YESTERDAY=`cat $FICH2/return_codes/RETURN_CODES_YESTERDAY_$FECHA.txt | grep "SET INTEGRITY FOR" | awk '{print $4}'`
	
	#EXPORT de registros
	regs_exported_today=`cat $FICH/result_export_today.txt | grep "Number of rows exported" | awk '{print $5}'`
	regs_exported_yesterday=`cat $FICH/result_export_yesterday.txt | grep "Number of rows exported" | awk '{print $5}'`
	tot_regs_exported=`expr $regs_exported_today + $regs_exported_yesterday`
	
	#LOAD de registros
	regs_loaded_today=`cat $FICH2/return_codes/RETURN_CODES_TODAY_$FECHA.txt | grep "Number of rows loaded" | awk '{print $6}'`
	regs_loaded_yesterday=`cat $FICH2/return_codes/RETURN_CODES_YESTERDAY_$FECHA.txt | grep "Number of rows loaded" | awk '{print $6}'`
	tot_regs_loaded=`expr $regs_loaded_today + $regs_loaded_yesterday`
	echo
	echo "RESULT:info - execution - " `date`
	echo " - Exported from: $TABLE_TO_EXPORT"
	echo " - TODAY: $TODAY"
	echo " - YESTERDAY: $YESTERDAY"
	echo 
	echo "regs_exported_today: $regs_exported_today"
	echo "regs_exported_yesterday: $regs_exported_yesterday"
	echo "regs_loaded_today on $table_histo_TODAY: $regs_loaded_today"
	echo "regs_loaded_yesterday on $table_histo_YESTERDAY: $regs_loaded_yesterday"
	echo "--------------------------------------------------------------------------"
	echo tot_regs_exported: $tot_regs_exported
	echo tot_regs_loaded: $tot_regs_loaded
	echo


    ######################################################################################
    ## PASO 5: BORRADO LA TABLA DESCARGADA                                             ##
    ######################################################################################

    echo
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo "DATA DELETION FROM ONLINE DB"
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo

	if [ $tot_regs_exported -gt 0 ] ; then
		#EVALUAMOS TODAY
		if [ $regs_exported_today -gt 0 ] ; then
			if [ $regs_exported_today -eq $regs_loaded_today ] ; then
			  #STATUS_OPERATION=0
			  echo "---------------------------------------------------------------------------------------------------------------"
			  echo "Deleting TODAY data from $TABLE_TO_EXPORT. Date: $TODAY    "
			  echo "---------------------------------------------------------------------------------------------------------------"
			  echo
			  func_delete_bycommit
			else
			  STATUS_OPERATION=4
			  echo
			  echo "WARNING: TODAY DATA EXPORTED, NOT EQUAL TO TODAY DATA IMPORTED - NO TODAY DATA DELETED FROM ONLINE DB "
			  echo
			fi
            #
            # After deletion we will check if the destination table partition its available
            # and has the same count record that earlier were eported and loaded.
            # This function also count records from the view perspective, just to be sure that
            # all the partitions are availables.
            #
            func_check_status_destination_table $table_histo_TODAY $regs_loaded_today
		else 
			echo
			echo "INFO: NOT TODAY DATA EXPORTED, NOT TODAY DATA IMPORTED - NOT TODAY DATA DELETED FROM ONLINE DB "
			echo
		fi
	
		#EVALUAMOS YESTERDAY
		if [ $regs_exported_yesterday -gt 0 ] ; then
			if [ $regs_exported_yesterday -eq $regs_loaded_yesterday ] ; then
			   #STATUS_OPERATION=0
			   echo "---------------------------------------------------------------------------------------------------------------"
			   echo "Deleting YESTERDAY data from $TABLE_TO_EXPORT. Date: $YESTERDAY    "
			   echo "---------------------------------------------------------------------------------------------------------------"
			   echo
			   func_delete_bycommit
			else
			   STATUS_OPERATION=4
			   echo
			   echo "WARNING: YESTERDAY DATA EXPORTED, NOT EQUAL TO YESTERDAY DATA IMPORTED - NO YESTERDAY DATA DELETED FROM ONLINE DB "
			   echo
			fi
            #
            # After deletion, we will check if the destination table partition its available
            # and has the same count record that earlier were eported and loaded.
            # This function also count records from the view perspective, just to be sure that
            # all the partitions are availables.
            func_check_status_destination_table $table_histo_YESTERDAY $regs_loaded_yesterday
		else 
			echo
			echo "INFO: NOT YESTERDAY DATA EXPORTED, NOT YESTERDAY DATA IMPORTED - NOT YESTERDAY DATA DELETED FROM ONLINE DB "
			echo 
		fi
	else
        STATUS_OPERATION=1
		echo
		echo "INFO: NO DATA EXPORTED - NO DATA IMPORTED - NO DATA DELETED FROM ONLINE DB "
		echo
	fi
fi
echo


######################################################################################
## PASO 6: BORRADO O ALMACEN TEMPORALES                                             ##
######################################################################################
if [ $STATUS_OPERATION -lt 4 ]; then
    echo
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo "FILES DELETION"
    echo ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"
    echo
  if [ ! -d "$FICH2/log" ] ; then mkdir "$FICH2/log" ; fi
  if [ ! -d "$FICH2/return_codes" ] ; then mkdir "$FICH2/return_codes" ; fi
  if [ ! -d "$FICH2/sql" ] ; then mkdir "$FICH2/sql" ; fi
  if [ -f "$FICH2/juliana.tmp" ] ; then mv "$FICH2/juliana.tmp" "$FICH2/log/juliana.`date +%d%m%Y_%H%M%S`.tmp" ; fi
  if [ -f "$FICH2/ayer.tmp" ] ; then mv "$FICH2/ayer.tmp" "$FICH2/log/ayer.`date +%d%m%Y_%H%M%S`.tmp" ; fi
  
  if [ $days_to_delete_export_dir -gt 0 ]; then
      echo "---------------------------------------------------------------------------------------------------------------"
      echo "Deleting DATA files older than $days_to_delete_export_dir from $FICH   "
      echo "---------------------------------------------------------------------------------------------------------------"
      find $FICH -type f \( -iname "*.msg" -o -iname "*.ixf" -o -iname "*.xml" -o -iname "*.txt" \) -mtime +$days_to_delete_export_dir -exec rm -f {} \; -print
  else
      echo "---------------------------------------------------------------------------------------------------------------"
      echo "NO DELETE SETUP FOR $FICH   "
      echo "---------------------------------------------------------------------------------------------------------------"
  fi
  
  if [ $days_to_delete_returnCodes_dir -gt 0 ]; then
      echo
      echo
      echo "---------------------------------------------------------------------------------------------------------------"
      echo "Deleting DATA files older than $days_to_delete_returnCodes_dir from $FICH2/return_codes   "
      echo "---------------------------------------------------------------------------------------------------------------"
      find $FICH2/return_codes -type f \( -iname "*.txt" \) -mtime +$days_to_delete_returnCodes_dir -exec rm -f {} \; -print
  else
      echo "---------------------------------------------------------------------------------------------------------------"
      echo "NO DELETE SETUP FOR $FICH2/return_codes   "
      echo "---------------------------------------------------------------------------------------------------------------"
  fi
  
  if [ $days_to_delete_log_dir -gt 0 ]; then
     echo
     echo
     echo "---------------------------------------------------------------------------------------------------------------"
     echo "Deleting DATA files older than $days_to_delete_log_dir from $FICH2/log   "
     echo "---------------------------------------------------------------------------------------------------------------"
     find $FICH2/log -type f \( -iname "*.tmp" \) -mtime +$days_to_delete_log_dir -exec rm -f {} \; -print
  else
      echo "---------------------------------------------------------------------------------------------------------------"
      echo "NO DELETE SETUP FOR $FICH2/log   "
      echo "---------------------------------------------------------------------------------------------------------------"
  fi
fi
#func_write_status_log "OPERATION_RESULT: $STATUS_OPERATION"
if [ "$STATUS_OPERATION" -gt "0" ];  then
  func_write_status_log "JOB FAILED WITH STATUS CODE : $STATUS_OPERATION"
  exit 1
else
  func_write_status_log "Script completed successfully  :  $STATUS_OPERATION"
  exit 0
fi
set +x

